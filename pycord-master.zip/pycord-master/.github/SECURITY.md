# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 2.0.0   | :white_check_mark: |
| <2.0.0  | :x:                |

## Reporting a Vulnerability

If you find a vulnerability you have two ways to report it:
- Write us on https://pycord.dev/discord
- Open an [issue](https://github.com/Pycord-Development/pycord/issues/new/choose)
